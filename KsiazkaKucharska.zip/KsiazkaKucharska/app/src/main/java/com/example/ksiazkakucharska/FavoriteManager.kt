package com.example.ksiazkakucharska

object FavoriteManager {
    private val favorites = mutableListOf<Meal>()

    fun add(meal: Meal) {
        if (!favorites.contains(meal)) favorites.add(meal)
    }

    fun remove(meal: Meal) {
        favorites.remove(meal)
    }

    fun isFavorite(meal: Meal): Boolean {
        return favorites.contains(meal)
    }

    fun getAll(): List<Meal> = favorites
}
