package com.example.ksiazkakucharska

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login) // Twój layout logowania

        val loginButton = findViewById<Button>(R.id.loginButton)
        loginButton.setOnClickListener {
            // Tworzymy Intent do RecipesActivity
            val intent = Intent(this, RecipesActivity::class.java)
            startActivity(intent)
            // finish() // możesz zostawić lub zakomentować, jeśli chcesz wrócić do logowania
        }
    }
}
