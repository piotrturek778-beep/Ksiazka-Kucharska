package com.example.ksiazkakucharska

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class RecipesAdapter(private var meals: List<Meal>) :
    RecyclerView.Adapter<RecipesAdapter.RecipeViewHolder>() {

    class RecipeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.mealTitle)
        val category: TextView = itemView.findViewById(R.id.mealCategory)
        val image: ImageView = itemView.findViewById(R.id.mealImage)
        val heart: ImageView = itemView.findViewById(R.id.heartIcon)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecipeViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_meal, parent, false)
        return RecipeViewHolder(view)
    }

    override fun getItemCount(): Int = meals.size

    override fun onBindViewHolder(holder: RecipeViewHolder, position: Int) {
        val meal = meals[position]

        holder.title.text = meal.strMeal
        holder.category.text = meal.strCategory

        Glide.with(holder.itemView.context)
            .load(meal.strMealThumb)
            .into(holder.image)

        // CLICK → przejście do szczegółów
        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context, DetailsActivity::class.java)
            intent.putExtra("meal", meal as java.io.Serializable)
            holder.itemView.context.startActivity(intent)
        }

        // SERDUSZKA
        var isFavorite = FavoriteManager.isFavorite(meal)
        updateHeartIcon(holder.heart, isFavorite)

        holder.heart.setOnClickListener {
            isFavorite = !isFavorite
            if (isFavorite) FavoriteManager.add(meal)
            else FavoriteManager.remove(meal)

            updateHeartIcon(holder.heart, isFavorite)
        }
    }

    private fun updateHeartIcon(heart: ImageView, isFavorite: Boolean) {
        if (isFavorite)
            heart.setImageResource(android.R.drawable.btn_star_big_on)
        else
            heart.setImageResource(android.R.drawable.btn_star_big_off)
    }

    fun updateData(newMeals: List<Meal>) {
        meals = newMeals
        notifyDataSetChanged()
    }
}
