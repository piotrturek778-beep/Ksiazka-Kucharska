package com.example.ksiazkakucharska

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

class DetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        val meal = intent.getSerializableExtra("meal") as? Meal
        if (meal == null) {
            finish()
            return
        }

        val image = findViewById<ImageView>(R.id.detailImage)
        val title = findViewById<TextView>(R.id.detailTitle)
        val category = findViewById<TextView>(R.id.detailCategory)
        val ingredients = findViewById<TextView>(R.id.detailIngredients)
        val instructions = findViewById<TextView>(R.id.detailInstructions)

        Glide.with(this)
            .load(meal.strMealThumb)
            .into(image)

        title.text = meal.strMeal ?: "Brak tytułu"
        category.text = "Kategoria: ${meal.strCategory ?: "Nieznana"}"

        val ingredientList = listOf(
            meal.strIngredient1,
            meal.strIngredient2,
            meal.strIngredient3,
            meal.strIngredient4,
            meal.strIngredient5,
            meal.strIngredient6,
            meal.strIngredient7,
            meal.strIngredient8,
            meal.strIngredient9,
            meal.strIngredient10
        ).filterNot { it.isNullOrBlank() }

        ingredients.text = ingredientList.joinToString("\n") { "- $it" }

        instructions.text = meal.strInstructions ?: "Brak instrukcji"
    }
}
