package com.example.ksiazkakucharska

import retrofit2.Call
import retrofit2.http.GET

interface MealApi {
    @GET("search.php?f=a")
    fun getMeals(): Call<MealResponse>
}

data class MealResponse(
    val meals: List<Meal>
)
